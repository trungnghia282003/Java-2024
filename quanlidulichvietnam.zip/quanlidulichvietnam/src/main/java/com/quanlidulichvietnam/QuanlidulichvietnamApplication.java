package com.quanlidulichvietnam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuanlidulichvietnamApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuanlidulichvietnamApplication.class, args);
	}

}
