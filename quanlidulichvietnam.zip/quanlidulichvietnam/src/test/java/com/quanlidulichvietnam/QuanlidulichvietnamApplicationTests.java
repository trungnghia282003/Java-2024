package com.quanlidulichvietnam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuanlidulichvietnamApplicationTests {

	@Test
	void contextLoads() {
	}

}
